//this file contains various file declarations and use data in the client code.

/*this is the user defined header
 file containing function declarations, macros and definitions of the structures used*/
#include"HABS.h"

//functions to display menu 
void displayMenu()
{
    printf("\n----------------***WELCOME TO APPOINTMENT BOOKING SYSTEM***----------------\n");
    printf("\n-----------------MENU-----------------");
    printf("\n\t Enter:\n\t 1 if you are patient\
	\n\t 2 if you are a doctor\
	\n\t 3 if you are a receptionist\
	\n\t 4 if you are an admin\
	\n\t 0 to exit\n");
	printf("---------------------------------------\n");
}//displayMenu() function ends.


/*getChoice() function takes no parameters and also do not returns any value.
It takes input from user the choice  and helps the user to traverse in the system*/
void getChoice()
{	
    int choice;
    do 		//infinite loop to run our program till exit(0) is encountered i.e. till user enters zero(0)
    {
        system("clear");
        displayMenu();
        printf("\n  Enter your choice: ");
        scanf("%d",&choice);
        printf("---------------------------------------\n");
        switch(choice)
        {
            case CLIENT_PATIENT:
				GetPatient();
				break;
            case CLIENT_RECEPTIONIST:
            	GetReceptionist();
            	break;
            case CLIENT_DOCTOR:
            	doctor_menu();
            	break;
            case CLIENT_ADMIN:
            	admin_menu();
            	break;
            case CLIENT_EXIT:
		    	printf("\n	***Thank You for using Hospital Appointment Booking System***	\n\n");
		    	exit(0);
            default:
            	printf("\n  Invalid Choice, Enter a valid option\n");
            	printf("---------------------------------------\n");
            	getchar();
            	printf("\n  Enter any key to continue");
            	getchar();
        }
        
    }while(choice!= EXIT);
}//getChoice() function ends.
