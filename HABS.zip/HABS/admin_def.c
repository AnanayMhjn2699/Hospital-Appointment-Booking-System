#include"admin.h"

/*Function to display  the starting menu to admin after
logging in, it neither takes in value nor returns anything */
void admin_menu()
{
	int admin_id,opt;
	int flag=1;
	char admin_password[20],ch;
	FILE *dptr;
	printf("\n--------------------WELCOME ADMIN--------------------\n\n");
	printf("Admin Login::\n");
	printf("Enter Admin ID: ");
	scanf("%d",&admin_id);
	printf("Enter password: ");
	scanf("%s",admin_password);
	admin_password[strlen(admin_password)]='\n';
	if(validate_admin(admin_id,admin_password))			//passing the variables to validate login function
	{
		printf("\nLogged in successfully...\n\n");
		while(flag)
		{
			printf("\n--------------ADMIN MENU--------------\n\n");
			printf("Choose an option...\n1) Doctor\n2) Receptionist\n3) LogOut\n0) Exit\nOption: ");
			scanf("%d",&opt);
			switch(opt)
			{
				case DOCTOR:
					admin_doctor_menu();
					continue;
				case RECEPTIONIST:
					admin_receptionist_menu();
					continue;
				case ADMIN_LOGOUT:
					printf("Logged out successfully..\n\n");
					
					flag=0;
					break;
					
				case EXIT:
					printf("\nThank you for using our services \nExited from Hospital Appointment Booking System..\n\n");
					exit(0);
				default:
					printf("Invalid Option!! Choose a valid option...\n");
					continue;
			}
		}
	}
	else
	{
		printf("\nIncorrect Admin ID/Password !!!\n");
		printf("Do you want to login again..?\n");
		printf("Choose y/n : ");
		while(getchar()!='\n');
		ch=getchar();
		if(ch=='Y' || ch=='y')
			admin_menu();
		else
		{
			printf("\nThank you for using our services \nExited from Hospital Appointment Booking System..\n\n");
			exit(0);
		}
	}
}


/*Function to validate the admin login credentials
Parameters: login id as integer and password as string and returns a integer value */
int validate_admin(int admin_id, char admin_password[20])
{
	char *token;
	FILE* fptr;
	admin ad;
	int count=0;
	char line[100];
	fptr=fopen(ADMIN_DETAILS_FILE,"r");
	if(fptr==NULL)
		printf("File doesn't exist\n");
	
	while(fgets(line,sizeof(line),fptr)!=NULL)
	{
		token=strtok(line,",");
		
		if(count==0)
		{
			ad.id=atoi(token);
			count++;
			token=strtok(NULL,",");
		}
		
		if(count==1)
		{
			strcpy(ad.password,token);
			token=strtok(NULL,",");
			count++;
		}
		if(admin_id==ad.id && strcmp(admin_password,ad.password)==0)
			return 1;
		count=0;
	}
	return 0;
}

/*Function to display  the doctror menu to admin after
logging in and selecting doctor, it neither takes in value nor returns anything */
void admin_doctor_menu()
{
	int choice,id,flag=1;
	char ch;
	admin_d_node *head;
	FILE *dptr;
	while(flag)
	{
		printf("\nChoose an option...\n1) Add Doctor\n2) Update Doctor\n3) Delete Doctor\n4) Display Doctor\n5) Go Back\n0) Exit\nOption: ");
		scanf("%d",&choice);
		switch(choice)
		{
			case ADD:
				head = add_doctor();
				dptr = fopen(DOCTOR_DETAILS_FILE,"a");	
				dptr=admin_doctor_write_to_file(dptr,head);
				fclose(dptr);
				printf("\nDoctor added successfully !!!\n\n");
				continue;
			case UPDATE:
				head=admin_doctor_read_from_file();
				printf("\nEnter the Doctor ID of the doctor you want to update the details: ");
				scanf("%d",&id);
				head=admin_doctor_update(id,head);
				dptr = fopen(DOCTOR_DETAILS_FILE,"w");	
				dptr=admin_doctor_write_to_file(dptr,head);
				fclose(dptr);
				printf("\nDoctor details updated successfully !!\n");
				continue;
			case DELETE:
				head=admin_doctor_read_from_file();
				printf("\nEnter the Doctor ID of the doctor you want to delete the details: ");
				scanf("%d",&id);
				head=admin_doctor_delete(id,head);
				dptr = fopen(DOCTOR_DETAILS_FILE,"w");	
				dptr=admin_doctor_write_to_file(dptr,head);
				fclose(dptr);
				continue;
			case DISPLAY:
				head=admin_doctor_read_from_file();
				printf("\nEnter the Doctor ID of the doctor you want to display the details: ");
				scanf("%d",&id);
				admin_doctor_display(id,head);
				continue;
			case GO_BACK:
					flag=0;
					break;
					
			case EXIT:
				admin_doctor_freeList(head);
				printf("\nThank you for using our services \nExited from Hospital Appointment Booking System..\n\n");
				exit(0);
			default:
				printf("Invalid Option!! Choose a valid option...\n");
				continue;
		}
	}
}

/*Function to display  the receptionist menu to admin after
logging in and selecting receptionist, it neither takes in value nor returns anything */
void admin_receptionist_menu()
{
	int choice,id,flag=1;
	char ch;
	r_node *head;
	FILE *rptr;
	while(flag)
	{
		printf("\nChoose an option...\n1) Add Receptionist\n2) Update Receptionist\n3) Delete Receptionist\n4) Display Receptionist\n5) Go Back\n0) Exit\nOption: ");
		scanf("%d",&choice);
		switch(choice)
		{
			case ADD:
				head = add_receptionist();
				rptr = fopen(RECEPTIONIST_DETAILS_FILE,"a");	
				rptr=admin_receptionist_write_to_file(rptr,head);
				fclose(rptr);
				printf("\nReceptionist added successfully !!!\n\n");
				continue;
			case UPDATE:
				head=admin_receptionist_read_from_file();
				printf("\nEnter the receptionist ID of the receptionist you want to update the details: ");
				scanf("%d",&id);
				head=admin_receptionist_update(id,head);
				rptr = fopen(RECEPTIONIST_DETAILS_FILE,"w");	
				rptr=admin_receptionist_write_to_file(rptr,head);
				fclose(rptr);
				printf("\nReceptionist details updated successfully !!\n");
				continue;
			case DELETE:
				head=admin_receptionist_read_from_file();
				printf("\nEnter the Receptionist ID of the receptionist you want to delete the details: ");
				scanf("%d",&id);
				head=admin_receptionist_delete(id,head);
				rptr = fopen(RECEPTIONIST_DETAILS_FILE,"w");	
				rptr=admin_receptionist_write_to_file(rptr,head);
				fclose(rptr);
				continue;
			case DISPLAY:
				head=admin_receptionist_read_from_file();
				printf("\nEnter the Receptionist ID of the receptionist you want to display the details: ");
				scanf("%d",&id);
				admin_receptionist_display(id,head);
				continue;
			case GO_BACK:
				flag=0;
				break;
			case EXIT:
				admin_receptionist_freeList(head);
				printf("\nThank you for using our services \nExited from Hospital Appointment Booking System..\n\n");
				exit(0);
			default:
				printf("Invalid Option!! Choose a valid option...\n");
				continue;
		}
	}
}

/*Function to add  the doctor details to be written to the file after
logging in and selecting doctor, it takes in no value and returns data as doctor's node */
admin_d_node* add_doctor()
{
	int check=0,count=0;
	admin_doctor doc;
	doc.userId=999;
	char line[200];
	char *token;
	FILE *fptr;
	admin_d_node *head,*newnode;
	head=NULL;
	newnode=NULL;
	fptr=fopen(DOCTOR_DETAILS_FILE,"r");
	if(fptr==NULL)
		printf("File doesn't exist\n");
	
	while(fgets(line,sizeof(line),fptr)!=NULL)
	{
		token=strtok(line,",");
	
		if(count==0)
		{
			doc.userId=atoi(token);
			count++;
			token=strtok(NULL,",");
		}
		count=0;
	}
	doc.userId++;
	printf("\nEnter the details to add a doctor:\n");
	    
	printf("\nPassword: ");
	scanf("%s",doc.password);
	
	printf("\nFirst name: ");
	while(1)
	{
		scanf("%s",doc.name);
		check=admin_validate_name(doc.name); //to validate name
		if(check==1)
			break;
		else
			printf("Enter valid name\n");
	}
	
	printf("\nLast name: ");
	while(1)
	{
		scanf("%s",doc.lname);
		check=admin_validate_name(doc.lname); //to validate name
		if(check==1)
			break;
		else
			printf("Enter valid name\n");
		
	
	}
	
	printf("\nEmail: ");
	while(1)
	{
		scanf("%s",doc.gmail);
		check=admin_validate_email(doc.gmail); //to validate email
		if(check==1)
			break;
		else
			printf("Enter valid email\n");
		
	}
	
	
	
	printf("\nPhone number: ");
	while(1)
	{
		scanf("%ld",&doc.phone_no);
		check=admin_validate_phone(doc.phone_no); //to validate phone number
		if(check==1)
			break;
		else
			printf("Enter valid phone number\n");
	}
	
	
	printf("\nShift hours: ");
	scanf("%d",&doc.shift_time);
	printf("\nDepartment Id: ");
	scanf("%d",&doc.dept_id);
	newnode=admin_doctor_create_node(doc);
	head=admin_doctor_add_node(head,newnode);
	printf("\nDoctor id of newly added doctor : %d",doc.userId);
		
	return head;
}

/*Function to validate phone number, takes in user entered number as long int
and returns 1 if number is valid otherwise 0*/
int admin_validate_phone(long phone_no)
{
    long digit;
    int count =0;
    digit = phone_no;
    while(phone_no>0)
    {
        count++;            // checking count of phone_no
        phone_no = phone_no/10;
    }
      // to see if phone_no count is  equal to 10 or not
    if (count == 10)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}


/*Function to validate email, takes in user entered email as string
and returns 1 if email is valid otherwise 0*/
int admin_validate_email(char *mail)
{
	if((mail[0] >= 'a' && mail[0] <= 'z') || (mail[0] >= 'A' || mail[0] <= 'Z'))
	{
		// check for @ sign
		int pos = -1;
		for(int i=0; i<strlen(mail); ++i)
		{
			if(mail[i] == '@') pos = i;
		}
		if(pos == -1) return 0;
		else
		{
			int pos2 = -1;
			for(int i=pos; i<strlen(mail); ++i)
			{
				// check for . after @ sign
				if(mail[i] == '.') 
					pos2 = i;
			}
			if(pos2 == -1 || pos2 == strlen(mail)-1)
				 return 0;
			else 
				return 1;
		}
	}
	else return 0;
}



/*Function to validate name, takes in user entered name as string
and returns 1 if name is valid otherwise 0*/
int admin_validate_name(char str[])
{
	int n,i,check;
	n=strlen(str);
	for(i=0;i<n;i++)
	{
		if((str[i]>='a' && str[i]<='z') || (str[i]>='A' && str[i]<='Z') || str[i]==' ')
			check=0;
		else
			return 0;
	}
	
	
	if(check==0)  //To check whether the name is valid
		return 1;
	else
		return 0;
}


//defining a function freeList to free the memory of the LL
//it will take he head node as a parameter
void admin_doctor_freeList(admin_d_node* head)
{
   admin_d_node* tmp;

   while (head != NULL)
    {
       tmp = head;
       head = head->next;
       free(tmp);
    }
    free(head);
}

/*function to free memory of LL used for adding receptionist data to file*/
void admin_receptionist_freeList(r_node* head)
{
   r_node* tmp;

   while (head != NULL)
    {
       tmp = head;
       head = head->next;
       free(tmp);
    }
    free(head);
}


//function to create doctor node 
//Parameters: structure variable of doctor and returns the new node created
admin_d_node* admin_doctor_create_node(admin_doctor d)
{
	admin_d_node *newnode= (admin_d_node*)malloc(sizeof(admin_d_node));
	
	newnode->doc.userId=d.userId;
	strcpy(newnode->doc.password,d.password);
	strcpy(newnode->doc.name,d.name);
	strcpy(newnode->doc.lname,d.lname);
	strcpy(newnode->doc.gmail,d.gmail);
	newnode->doc.phone_no=d.phone_no;
	newnode->doc.shift_time=d.shift_time;
	newnode->doc.dept_id=d.dept_id;
	
	return newnode;
}

//function to add doctor node 
//Paramaters: 2 pointers of linked list
admin_d_node* admin_doctor_add_node(admin_d_node *head,admin_d_node *newnode)
{
    admin_d_node *temp=head;
    //check if LL is empty
    if(head==NULL)
         head = newnode;
    else
    {
        while(temp->next!=NULL)
              temp = temp->next;
          
        temp->next = newnode; 
    }

   return head;
}

/*this function writes the data to the doctor file*/
FILE* admin_doctor_write_to_file(FILE *dptr2, admin_d_node *head)
{
	admin_d_node *temp=head;
	
	while(temp!=NULL)
	{
		fprintf(dptr2,"%d,%s,%s,%s,%s,%ld,%d,%d\n",temp->doc.userId, temp->doc.password,temp->doc.name,temp->doc.lname,temp->doc.gmail,temp->doc.phone_no,temp->doc.shift_time,temp->doc.dept_id);
		temp=temp->next;
	}
	
	return dptr2;
	
}

//function to create receptionist node 
//Parameters: structure variable of receptionist and returns the new node created
r_node* admin_receptionist_create_node(receptionist r)
{
	r_node *newnode= (r_node*)malloc(sizeof(r_node));
	
	newnode->rec.userId=r.userId;
	strcpy(newnode->rec.password,r.password);
	strcpy(newnode->rec.name,r.name);
	strcpy(newnode->rec.lname,r.lname);
	strcpy(newnode->rec.gmail,r.gmail);
	newnode->rec.phone_no=r.phone_no;
	newnode->rec.shift_time=r.shift_time;
	
	return newnode;
}



//function to add receptionist node 
//Paramaters: 2 pointers of linked list
r_node* admin_receptionist_add_node(r_node *head,r_node *newnode)
{
    r_node *temp=head;
    //check if LL is empty
    if(head==NULL)
         head = newnode;
    else
    {
        while(temp->next!=NULL)
              temp = temp->next;
          
        temp->next = newnode; 
    }

   return head;
}

/*Function to add  the receptionist details to be written to the file after
logging in and selecting receptionist, it takes in no value and returns receptionist's node */
r_node* add_receptionist()
{
	int check=0,count=0;
	receptionist rec;
	rec.userId=1999;
	char line[200];
	char *token;
	FILE *fptr;
	r_node *head,*newnode;
	head=NULL;
	newnode=NULL;
	fptr=fopen(RECEPTIONIST_DETAILS_FILE,"r");
	if(fptr==NULL)
		printf("File doesn't exist\n");
	
	while(fgets(line,sizeof(line),fptr)!=NULL)
	{
		token=strtok(line,",");
	
		if(count==0)
		{
			rec.userId=atoi(token);
			count++;
			token=strtok(NULL,",");
		}
		count=0;
	}
	rec.userId++;
	printf("\nEnter the details to add a receptionist:\n");
			    
	printf("\nPassword: ");
	scanf("%s",rec.password);
	
	printf("\nFirst Name: ");
	while(1)
	{
		scanf("%s",rec.name);
		check=admin_validate_name(rec.name); //to validate name
		if(check==1)
			break;
		else
			printf("Enter valid name\n");
	}
	
	
	printf("\nLast name: ");
	while(1)
	{
		scanf("%s",rec.lname);
		check=admin_validate_name(rec.lname); //to validate name
		if(check==1)
			break;
		else
			printf("Enter valid name\n");
	}
	
	
	printf("\nEmail: ");
	while(1)
	{
		scanf("%s",rec.gmail);
		check=admin_validate_email(rec.gmail); //to validate email
		if(check==1)
			break;
		else
			printf("Enter valid email\n");
		
	}
	
	printf("\nPhone number: ");
	while(1)
	{
		scanf("%ld",&rec.phone_no);
		check=admin_validate_phone(rec.phone_no); //to validate phone number
		if(check==1)
			break;
		else
			printf("Enter valid phone number\n");
	}
	
	printf("\nShift hours: ");
	scanf("%d",&rec.shift_time);
	
	newnode=admin_receptionist_create_node(rec);
	head=admin_receptionist_add_node(head,newnode);
	printf("\nReceptionist id of newly added receptionist : %d",rec.userId);
	
	return head;
}


/*this function writes the data to the receptionist file*/
FILE* admin_receptionist_write_to_file(FILE *rptr, r_node *head)
{
	r_node *temp=head;
	
	while(temp!=NULL)
	{
		fprintf(rptr,"%d,%s,%s,%s,%s,%ld,%d\n",temp->rec.userId, temp->rec.password,temp->rec.name,temp->rec.lname,temp->rec.gmail,temp->rec.phone_no,temp->rec.shift_time);
		temp=temp->next;
	}
	
	return rptr;
}

/*Function to read data from the file
Parameters: head pointer of the linked list and file pointer
Returns the head pointer of the linked list*/
admin_d_node* admin_doctor_read_from_file()
{
	char *token;
	int cont=0;
	FILE* fptr;
	admin_doctor doc;
	int count=0;
	admin_d_node *head,*newnode;
	head=NULL;
	newnode=NULL;
	char line[200];
	char *end[20];
	fptr=fopen("text_files/doctor_details.txt","r");
	
	if(fptr==NULL)
		printf("File doesn't exist\n");
	
	while(fgets(line,200,fptr)!=NULL)
	{
	
		token=strtok(line,",");
		
		if(count==0)
		{
			doc.userId=atoi(token);
			count++;
			token=strtok(NULL,",");
		}
		
		if(count==1)
		{
			strcpy(doc.password,token);
			token=strtok(NULL,",");
			count++;
		}
		if(count==2)
		{
			strcpy(doc.name,token);
			token=strtok(NULL,",");
			count++;
		}
		
		if(count==3)
		{
			strcpy(doc.lname,token);
			token=strtok(NULL,",");
			count++;
		}
		if(count==4)
		{
			strcpy(doc.gmail,token);
			token=strtok(NULL,",");
			count++;
		}
		if(count==5)
		{
			doc.phone_no=strtol(token,end,10);
			token=strtok(NULL,",");
			count++;
		}
		if(count==6)
		{
			doc.shift_time=atoi(token);
			token=strtok(NULL,",");
			count++;
		}
		if(count==7)
		{
			doc.dept_id=atoi(token);
			token=strtok(NULL,",");
			
		}
		count=0;
		cont++;
		newnode=admin_doctor_create_node(doc);
		head=admin_doctor_add_node(head,newnode);
	}
	fclose(fptr);
	return head;
}

//Function to display the doctor details
//Paramaters: integer, head pointer of the linked list and  no return type
void admin_doctor_display(int id,admin_d_node *head)
{
	int check=0;
	admin_d_node *temp=head;
	
	while(temp!=NULL && id!=temp->doc.userId)
	{
		temp=temp->next;
		
	}
	
	if(temp!=NULL)
	{
		printf("\nDetails of the doctor are ::");
		printf("\nDoctor ID : %d",temp->doc.userId);	
		printf("\nName: %s %s",temp->doc.name,temp->doc.lname);
		printf("\nEmail id : %s",temp->doc.gmail);
		printf("\nPhone No. : %ld",temp->doc.phone_no);
		printf("\nShift Hours : %d",temp->doc.shift_time);
		printf("\nDepartment id : %d\n",temp->doc.dept_id);
	}
	else
		printf("\nNo doctor exists with the ID you entered.\n");
}

//Function to update a record using user Id 
//Paramaters: integer and head pointer of the linked list and return type: head pointer of the updated list
admin_d_node* admin_doctor_update(int id,admin_d_node* head)
{
	admin_d_node *temp=head;
	int check=0;
	int shift_time,dept_id;
	char name[20],lname[20],gmail[20],password[20];
	long phone_no;
	
		
	while(temp!=NULL && id!=temp->doc.userId)
		{
			temp=temp->next;
			
		}
		
	if(temp!=NULL)
	{
		printf("Doctor Name: %s",temp->doc.name);
		printf("\nEnter new details of the doctor :\n");
		printf("\nPassword: ");
		scanf("%s",password);
		
		printf("\nFirst name: ");
		while(1)
		{
			scanf("%s",name);
			check=admin_validate_name(name); //to validate name
			if(check==1)
				break;
			else
				printf("Enter valid name\n");
		}
		
		printf("\nLast name: ");
		while(1)
		{
			scanf("%s",lname);
			check=admin_validate_name(lname); //to validate name
			if(check==1)
				break;
			else
				printf("Enter valid name\n");
		}
		
		printf("\nEmail: ");
		while(1)
		{
			scanf("%s",gmail);
			check=admin_validate_email(gmail); //to validate email
			if(check==1)
				break;
			else
				printf("Enter valid email\n");
		}
		
		printf("\nPhone number: ");
		while(1)
		{
			scanf("%ld",&phone_no);
			check=admin_validate_phone(phone_no); //to validate phone number
			if(check==1)
				break;
			else
				printf("Enter valid phone number\n");
		}
		
		printf("\nShift time: ");
		scanf("%d",&shift_time);
		
		printf("\nDepartment Id:");
		scanf("%d",&dept_id);
		
		strcpy(temp->doc.password,password);
		strcpy(temp->doc.name,name);
		strcpy(temp->doc.lname,lname);
		strcpy(temp->doc.gmail,gmail);
		temp->doc.phone_no=phone_no;
		temp->doc.shift_time=shift_time;
		temp->doc.dept_id= dept_id;
	}		
	else
		printf("\nNo doctor exists with the ID you entered.\n");
		
	return head;
}



//Function to delete a record using user Id 
//Paramaters: integer and head pointer of the linked list and return type: head pointer of the updated list
admin_d_node* admin_doctor_delete(int id,admin_d_node *head)
{
	
		admin_d_node *temp=head;
		admin_d_node *temp2=NULL;
		
		if(temp->doc.userId==id)
		{
			head=head->next;
			free(temp);
			temp=NULL;
			printf("\nDoctor Deletion successfull\n");
			return head;
		}
		while(temp!=NULL && id!=temp->doc.userId)
		{
			temp2=temp;
			temp=temp->next;
			
		}
		
		if(temp!=NULL)
		{
			temp2->next=temp->next;
			free(temp);
			temp=NULL;
			printf("\nDoctor Deletion successfull !!\n");
			
		}
		else
			printf("\nNo doctor exists with the ID you entered.\n");
		
		return head;
	
}

//Function to display the receptionist details
//Paramaters: integer, head pointer of the linked list and  no return type
void admin_receptionist_display(int id,r_node *head)
{
	int check=0;
		r_node *temp=head;
		
		while(temp!=NULL && id!=temp->rec.userId)
		{
			temp=temp->next;
			
		}
		
		if(temp!=NULL)
		{
			printf("\nDetails of the receptionist are ::");
			printf("\nReceptionist ID is: %d",temp->rec.userId);
			printf("\nName: %s %s",temp->rec.name,temp->rec.lname);
			printf("\nEmail id : %s",temp->rec.gmail);
			printf("\nPhone No. : %ld",temp->rec.phone_no);
			printf("\nShift Hours : %d\n",temp->rec.shift_time);
		}
		else
			printf("\nNo receptionist exists with the ID you entered.\n");
}




//Function to update a record using user Id 
//Paramaters: integer and head pointer of the linked list and return type: head pointer of the updated list
r_node* admin_receptionist_update(int id,r_node* head)
{
	r_node *temp=head;
	int shift_time;
	char name[20],lname[20],gmail[20],password[20];
	long phone_no;
	int check=0;
	
		
	while(temp!=NULL && id!=temp->rec.userId)
		{
			temp=temp->next;
			
		}
		
	if(temp!=NULL)
	{
		printf("\nEnter new details of the receptionist :\n");
		
		printf("\nPassword: ");
		scanf("%s",password);
		
		printf("\nFirst name: ");
		while(1)
		{
			scanf("%s",name);
			check=admin_validate_name(name); //to validate name
			if(check==1)
				break;
			else
				printf("Enter valid name\n");
		}
		
		printf("\nLast name: ");
		while(1)
		{
			scanf("%s",lname);
			check=admin_validate_name(lname); //to validate name
			if(check==1)
				break;
			else
				printf("Enter valid name\n");
		}
		
		printf("\nEmail: ");
		while(1)
		{
			scanf("%s",gmail);
			check=admin_validate_email(gmail); //to validate email
			if(check==1)
				break;
			else
				printf("Enter valid email\n");
		}
		
		
		printf("\nPhone number: ");
		while(1)
		{
			scanf("%ld",&phone_no);
			check=admin_validate_phone(phone_no); //to validate phone number
			if(check==1)
				break;
			else
				printf("Enter valid phone number\n");
			}
			
			printf("\nShift time: ");
			scanf("%d", &shift_time);
			
			strcpy(temp->rec.password,password);
			strcpy(temp->rec.name,name);
			strcpy(temp->rec.lname,lname);
			strcpy(temp->rec.gmail,gmail);
			temp->rec.phone_no=phone_no;
			temp->rec.shift_time=shift_time;
		
	}
				
	else
		printf("\nNo receptionist exists with the ID you entered.\n");
		
	return head;
}



//Function to delete a record using user Id 
//Paramaters: integer and head pointer of the linked list and return type: head pointer of the updated list
r_node* admin_receptionist_delete(int id,r_node *head)
{
	
		r_node *temp=head;
		r_node *temp2=NULL;
		
		if(temp->rec.userId==id)
		{
			head=head->next;
			free(temp);
			temp=NULL;
			printf("\nReceptionist Deletion succesful\n");
			return head;
		}
		while(temp!=NULL && id!=temp->rec.userId)
		{
			temp2=temp;
			temp=temp->next;
			
		}
		
		if(temp!=NULL)
		{
			temp2->next=temp->next;
			free(temp);
			temp=NULL;
			printf("\nReceptionist Deletion succesful\n");
			
		}
		else
			printf("\nNo receptionist exists with the ID you entered.\n");
		
		return head;
	
}

//Function to read data from the file
//Parameters: head pointer of the linked list and file pointer
//Returns the head pointer of the linked list
r_node* admin_receptionist_read_from_file()
{
	char *token;
	FILE* r_fptr;
	receptionist rec;
	int count=0;
	int c=0;
	r_node *head,*newnode;
	head=NULL;
	newnode=NULL;
	char line[100];
	char *end[20];
	r_fptr=fopen(RECEPTIONIST_DETAILS_FILE,"r");
	
	
	if(r_fptr==NULL)
		printf("File doesn't exist\n");
	
	 while(fgets(line,sizeof(line),r_fptr)!=NULL)
	 {
	
		token=strtok(line,",");
		
		if(count==0)
		{
			rec.userId=atoi(token);
			count++;
			token=strtok(NULL,",");
		}
		
		if(count==1)
		{
			strcpy(rec.password,token);
			token=strtok(NULL,",");
			count++;
		}
		if(count==2)
		{
			strcpy(rec.name,token);
			token=strtok(NULL,",");
			count++;
		}
		if(count==3)
		{
			strcpy(rec.lname,token);
			token=strtok(NULL,",");
			count++;
		}
		if(count==4)
		{
			strcpy(rec.gmail,token);
			token=strtok(NULL,",");
			count++;
		}
		if(count==5)
		{
			rec.phone_no=strtol(token,end,10);
			token=strtok(NULL,",");
			count++;
		}
		if(count==6)
		{
			rec.shift_time=atoi(token);
			token=strtok(NULL,",");
			count++;
		}
		count=0;
		c++;
		newnode=admin_receptionist_create_node(rec);
		head=admin_receptionist_add_node(head,newnode);
	}
	
	fclose(r_fptr);
	return head;
}

