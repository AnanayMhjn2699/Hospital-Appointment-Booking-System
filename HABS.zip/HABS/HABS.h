//this file contains headers to be used in the client code,it is the header file to be included in the client code

/*this is the user defined header
 file containing function declarations, macros and definitions of the structures used in the receptionist's module*/
#include "receptionist.h"

/*this is the user defined header
 file containing function declarations, macros and definitions of the structures used in the admin's module*/
#include "admin.h"

/*this is the user defined header
 file containing function declarations, macros and definitions of the structures used in the doctor's module*/
#include"doctor.h"

/* ! DO NOT INCLUDE "patient.h"  as it is already included in receptionist.h*/

//various macros used in the module
#define CLIENT_PATIENT 1
#define CLIENT_DOCTOR 2
#define CLIENT_RECEPTIONIST 3
#define CLIENT_ADMIN 4
#define CLIENT_EXIT 0

//***these are the various declarations of the functions used in the client code***

//functions to display menu 
void displayMenu();

//functions to get user's choice
void getChoice();

