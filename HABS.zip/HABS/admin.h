//Admin header file
#include<stdio.h>
#include<stdlib.h>
#include<string.h>

//defining macros for better visibility of options in the switch case
#define DOCTOR 1
#define RECEPTIONIST 2
#define ADD 1
#define UPDATE 2
#define DELETE 3
#define DISPLAY 4
#define LOGOUT 5
#define EXIT 0
#define ADMIN_LOGOUT 3
#define GO_BACK 5

//various macros storing the file paths used in the module
#define DEPARTMENT_FILE "text_files/dept_details.txt"
#define DOCTOR_DETAILS_FILE "text_files/doctor_details.txt"
#define APPOINTMENT_DETAILS_FILE "text_files/appointment_details.txt"
#define RECEPTIONIST_DETAILS_FILE "text_files/receptionist_details.txt"
#define ADMIN_DETAILS_FILE "text_files/admin_details.txt"


//Structure for reading and writing admin details
typedef struct Admin
{
	int id;
	char name[20];
	char password[20];
	
}admin;

//Structure for reading and writing doctor details in the admin module	
typedef struct admin_Doctor{

	int userId;
	char password[20];
	char name[20];
	char lname[20];
	char gmail[20];
	long phone_no;
	int shift_time;
	int dept_id;
}admin_doctor;
	
//Structure for  LL to read and write doctor details in the admin module
typedef struct admin_Doctor_LL{

	admin_doctor doc;
	struct admin_Doctor_LL *next;

}admin_d_node;

//Structure for reading and writing receptionist details in the admin module
typedef struct Receptionist{

	int userId;
	char password[30];
	char name[30];
	char lname[30];
	char gmail[30];
	long phone_no;
	int shift_time;
}receptionist;
	
//Structure for LL to read and write receptionist details in the admin module
typedef struct Receptionist_LL{

	receptionist rec;
	struct Receptionist_LL *next;

}r_node;


/*Function to validate the admin login credentials
Parameters: login id as integer and password as string and returns a integer value */
int validate_admin(int,char []);

/*Function to validate phone number, takes in user entered phone number as long integer
and returns 1 ifphone no is valid otherwise 0*/
int admin_validate_phone(long);

/*Function to validate email, takes in user entered email id as string
and returns 1 if email is valid otherwise 0*/
int admin_validate_email(char[]);

/*Function to validate name, takes in user entered name as string
and returns 1 if name is valid otherwise 0*/
int admin_validate_name(char[]);

/*Function to display the starting menu to admin after
logging in, it neither takes in value nor returns anything */
void admin_menu();

/*Function to display  the doctror menu to admin after
logging in and selecting doctor, it neither takes in value nor returns anything */
void admin_doctor_menu();

/*Function to display  the receptionist menu to admin after
logging in and selecting receptionist, it neither takes in value nor returns anything */
void admin_receptionist_menu();

/*Function to add  the doctror details to be written to the file after
logging in and selecting doctor, it takes in no value and returns doctor's node */
admin_d_node* add_doctor();

/*Function to add  the receptionist details to be written to the file after
logging in and selecting receptionist, it takes in no value and returns receptionist's node */
r_node* add_receptionist();

/*function to free memory of LL used for adding doctor data to file*/
void admin_doctor_freeList(admin_d_node*);

/*function to free memory of LL used for adding receptionist data to file*/
void admin_receptionist_freeList(r_node*);

//function to create doctor node 
//Parameters: structure variable of doctor and returns the new node created
admin_d_node* admin_doctor_create_node(admin_doctor);

//function to add doctor node 
//Paramaters: 2 pointers of linked list
admin_d_node* admin_doctor_add_node(admin_d_node*,admin_d_node*);

/*this function writes the data to the doctor file*/
FILE* admin_doctor_write_to_file(FILE*, admin_d_node*);

//function to create receptionist node 
//Parameters: structure variable of receptionist and returns the new node created
r_node* admin_receptionist_create_node(receptionist);

//function to add receptionist node 
//Paramaters: 2 pointers of linked list
r_node* admin_receptionist_add_node(r_node*,r_node*);

/*this function writes the data to the receptionist file*/
FILE* admin_receptionist_write_to_file(FILE*,r_node*);

/*Function to read data from the file
Parameters: head pointer of the linked list and file pointer
Returns the head pointer of the linked list*/
admin_d_node* admin_doctor_read_from_file();

//Function to display the doctor details
//Paramaters: integer, head pointer of the linked list and  no return type
void admin_doctor_display(int,admin_d_node*);

//Function to update a record using user Id 
//Paramaters: integer and head pointer of the linked list and return type: head pointer of the updated list
admin_d_node* admin_doctor_update(int,admin_d_node*);

//Function to delete a record using user Id 
//Paramaters: integer and head pointer of the linked list and return type: head pointer of the updated list
admin_d_node* admin_doctor_delete(int,admin_d_node*);

//Function to read data from the file
//Parameters: head pointer of the linked list and file pointer
//Returns the head pointer of the linked list
r_node* admin_receptionist_read_from_file();

//Function to delete a record using user Id 
//Paramaters: integer and head pointer of the linked list and return type: head pointer of the updated list
r_node* admin_receptionist_delete(int id,r_node*);

//Function to update a record using user Id 
//Paramaters: integer and head pointer of the linked list and return type: head pointer of the updated list
r_node* admin_receptionist_update(int,r_node*);


//Function to display the receptionist details
//Paramaters: integer, head pointer of the linked list and  no return type
void admin_receptionist_display(int,r_node*);

