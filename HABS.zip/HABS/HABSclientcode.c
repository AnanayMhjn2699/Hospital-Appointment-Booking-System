/*this file contains the client code for the hospital appointment booking system*/

/*this is the user defined header
 file containing function declarations, macros and definitions of the structures used*/
#include"HABS.h"

/*main function is the client code of the system, will help the user to traverse and use the system*/
int main()
{
    getChoice();	//the function to get user choice for traversing the system
    return 0;
}
