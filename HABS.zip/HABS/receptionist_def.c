#include "receptionist.h"

/* Reposition the cursor */
void Reset_Cursor()
{
	sleep(1); // wait for 1 second
	for(int i=0; i<3; ++i)
	{
		printf("\33[2K"); // erase the entire line, cursor does not move to the beginning of line
		printf("\033[A"); // moves up one row, cursor does not move to the beginning of line
	}
	printf("\33[2K");
	printf("\r"); // cursor moves to the beginning of line
}

/* Function to check for valid Appointment ID. Function takes one argument appointment ID. Function returns an integer (1 = True, 0 = False) */
int Receptionist_isValid_Appointment(int app_id)
{
	int a_id,flg = 0;
	char buff[100];
	
	FILE *fptr;
	fptr = fopen(APPOINTMENT_DETAILS,"r"); /* Opening file in read mode */
	
	if(fptr == NULL)
	{
		printf("\nError! Cannot Open File...\n");
		exit(1);
	}
	
	while(fgets(buff,sizeof(buff),fptr) != NULL)
	{
		char *token = strtok(buff,",");
		a_id = atoi(token); // converting string to int
		if(a_id == app_id)
		{
			flg = 1;
			break;
		}
	}
	
	fclose(fptr);
	return flg;
}

/* Function to check for valid receptionist ID and password. Function takes two parameters receptionist ID and receptionist password. Function returns an integer (1 = True, 0 = False) */
int Receptionist_isValid_Receptionist(int rec_id, char *password)
{ 
	int r_id,flg = 0;
	char buff[100];
	
	FILE *fptr;
	fptr = fopen(RECEPTIONIST_DETAILS,"r"); /* Opening file in read mode */
	
	if(fptr == NULL)
	{
		printf("\nError! Cannot Open File...\n");
		exit(1);
	}
	
	while(fgets(buff,sizeof(buff),fptr) != NULL)
	{
		char* token = strtok(buff,",");
		r_id = atoi(token); // convert string to int;
		if(r_id == rec_id)
		{ 
			token = strtok(NULL,",");
			if(strcmp(token,password) == 0)
			{
				flg = 1;
				break;
			}
		}
	}
	
	fclose(fptr);
	return flg;
}

/* Function for regular patient. Function takes no parameters. Function returns void (nothing) */
void Receptionist_regularPatient()
{
	int p_id,ch; 
	char pass[20];
	
	do{
		system("clear");
		printf("\n---------------- *** Welcome Patient *** ----------------\n");
		printf("\nEnter Patient ID : ");
		scanf("%d",&p_id);
		printf("Enter Password   : ");
		scanf("%s",pass);
	
		int valid = isValidCredentials(p_id,pass); // function to validate patient username and password
		
		if(valid)
		{
			printf("\nLogin Successfull\n\n");
			BookAppointment(p_id); // Function to book an appointment
			ch = 0;
		}
		else
		{
			printf("\nEnter valid Patient ID/Password\n");
			printf("\nDo you Want to Login Again ? (1/0) : ");
			scanf("%d",&ch);
		}
	}while(ch == 1);
}

/* Function to invoke patient Module. Function takes no parameters. Function returns void (nothing) */
void Receptionist_GetPatient()
{
	int ch;
	do{
		while(1)
		{
			system("clear");
			printf("\n\n-----------------*** Patient Menu ***-----------------\n");
			printf("\n\t\t1. New Patient\n\t\t2. Regular Patient\n\t\t0. Go Back\n");
			printf("\nEnter your choice :: ");
			scanf("%d",&ch);
			if(ch < 0 || ch > 3) 
				continue;
			else 
				break;
		}
		
		switch(ch)
		{
			case 1:
				newPatient();
				break;
			case 2:
				Receptionist_regularPatient();
				break;
			case 0:
				break;
		}
		
		if(ch != 0)
		{
			printf("\nGo Back to Patient Menu (1/0) : ");
			scanf("%d",&ch);
		}
	}while(ch == 1);
}

/* Function to Cancel an Appointment. Function takes no parameters. Function returns void (nothing) */
void Receptionist_Cancel_Appointment()
{
	
	int app_id,doc_id,ch;
	char buff[120];
	appointment* head = NULL;
	head = acceptAppointment(head); // function to read appointment details from file and store in Linked List
	
	if(head == NULL)
	{
		printf("\n\n-----------------------------\n");
		printf("No Appointments to Cancel !");
		printf("\n-----------------------------\n\n");
		return;
	}
	
	do{
		ch = 0;
		printf("\nEnter Appointment ID : ");
		scanf("%d",&app_id);
		int valid = Receptionist_isValid_Appointment(app_id); // function to check if Appointment ID is valid or not
		if(valid)
		{
			// Get Doctor ID to update doctor availability to "n" after appointment is cancelled
			FILE *fptr;
			fptr = fopen(APPOINTMENT_DETAILS,"r");
			
			if(fptr == NULL)
			{
				printf("\nError ! Cannot Open File\n");
				exit(1);
			}
			
			while(fgets(buff,sizeof(buff),fptr) != NULL)
			{
				char *token = strtok(buff,",");
				int a_id = atoi(token);
				if(a_id == app_id)
				{
					token = strtok(NULL,",");
					token = strtok(NULL,",");
					doc_id = atoi(token);
					break;
				}
			}
			fclose(fptr);
			
			head = removeNode(head,app_id); // function to delete record associated with app_id
			
			fptr = fopen(APPOINTMENT_DETAILS,"w");
			
			if(fptr == NULL)
			{
				printf("\nError! Cannot Open File...\n");
				exit(1);
			}
			
			appointment* temp = head;
			while(temp != NULL)
			{
			//app_id, pat_id, doc_id, pat_fname, pat_lname, doc_fname, doc_lname, department, app_date, app_time
				fprintf(fptr,"%d,%d,%d,%s,%s,%s,%s,%s,%d/%d/%d,%d:%d:%d",temp->appointmentID,temp->patientID,temp->doctorID,temp->pat_name.fname,temp->pat_name.lname,temp->doc_name.fname,temp->doc_name.lname,temp->dept,temp->dt.day,temp->dt.mon,temp->dt.year,temp->dt.hrs,temp->dt.min,temp->dt.sec);
				if(temp->next != NULL) 
					fprintf(fptr,"\n");
					
				temp = temp->next;	
			}
			
			while(head != NULL)
			{
				temp = head;
				head = head->next;
				free(temp);
			}
			
			fclose(fptr);
			printf("\nAppointment #%d Cancelled !\n",app_id);
			updateDoctorAvailability(doc_id); // function to update doctors availability after appointment is cancelled
		}
		else
		{
			printf("\n----------------------------------");
			printf("\nEnter valid Appointment ID !\n");
			printf("----------------------------------\n");
			
			printf("\nDo you wish to continue (1/0): ");
			scanf("%d",&ch);
		}
	}while(ch == 1);
}

/* Function to Display Appointment. Function takes no parameters. Function returns nothing */
void Receptionist_Display_Appointment()
{
	int app_id,ch;
	
	do{
		ch = 0;
		printf("\nEnter Appointment ID : ");
		scanf("%d",&app_id);
		int valid = Receptionist_isValid_Appointment(app_id); // function to check if Appointment ID is valid or not
		
		if(valid)
		{
			int a_id;
			char buff[100];
			char st[10][15];
			
			FILE *fptr;
			fptr = fopen(APPOINTMENT_DETAILS,"r");
			
			if(fptr == NULL)
			{
				printf("\nError! Cannot Open File...\n");
				exit(1);
			}
			
			while(fgets(buff,sizeof(buff),fptr) != NULL)
			{
				char *token = strtok(buff,",");
				int p=0;
				while(token != NULL)
				{
					strcpy(st[p],token);
					token = strtok(NULL,",");
					p++;
				}
				a_id = atoi(st[0]); // converting string to int
				if(a_id == app_id)
				{
					printf("\n-----------------*** Appointment Details ***-----------------\n\n");
					printf("Appointment ID   :: %s\n",st[0]);
					printf("Patient ID       :: %s\n",st[1]);
					printf("Doctor ID        :: %s\n",st[2]);
					printf("Patient Name     :: %s %s\n",st[3],st[4]);
					printf("Doctor Name      :: %s %s\n",st[5],st[6]);
					printf("Department       :: %s\n",st[7]);
					printf("Appointment Date :: %s\n",st[8]);
					printf("Appointment Time :: %s\n",st[9]);
					break;
				}
			}
			fclose(fptr);
		}
		else
		{
			printf("\n----------------------------------");
			printf("\nEnter valid Appointment ID !\n");
			printf("----------------------------------\n");
			
			printf("\nDo you wish to continue (1/0): ");
			scanf("%d",&ch);
		}
	}while(ch == 1);
}

/* Function to display Receptionist Menu. Function takes no parameters. Function returns void (nothing) */
void Receptionist_displayMenu()
{
	int ch;
	do{
		while(1)
		{
			system("clear");
			printf("\n\n--------------*** Receptionist Menu ***--------------\n");
			printf("\n\t\t1. Book Appointment\n\t\t2. Cancel Appointment\n\t\t3. Display Appointment\n\t\t4. Logout\n\t\t0. Exit\n");
			printf("\nEnter your choice :: ");
			scanf("%d",&ch);
			if(ch < 0 || ch > 4)
			{
				system("clear");
				continue;
			}
			break;
		}
		
		
		switch(ch)
		{
			case R_BOOK:
				Receptionist_GetPatient();
				break;
			case R_CANCEL:
				Receptionist_Cancel_Appointment();
				break;
			case R_DISPLAY:
				Receptionist_Display_Appointment();
				break;
			case R_LOGOUT:
				ch = 0;
				break;
			case R_EXIT:
				printf("\n\n***THANK YOU FOR USING THE APPOINTMENT BOOKING SYSTEM***\n\n");
				exit(0);
		}
		if(ch != 0)
		{
			printf("\nGo Back to Receptionist Menu (1/0) : ");
			scanf("%d",&ch);
		}
		if(ch == 0)
		{
			printf("\nYou've been Logged Out !\n");
		}
	}while(ch != 0);
}

/* Function to invoke Receptionist Module. Function takes no parameters. Function return void (nothing) */
void GetReceptionist()
{
	
	int rec_id,ch;
	char password[20];
	
	do{
		system("clear");
		
		printf("\n-----------------*** Welcome Receptionist ***-----------------\n");
		printf("\nEnter Receptionist ID       :: ");
		scanf("%d",&rec_id);
		
		printf("Enter Receptionist password :: ");
		scanf("%s",password);
		password[strlen(password)] = '\0';
	
		int valid = Receptionist_isValid_Receptionist(rec_id,password);
		
		if(valid)
		{
			printf("\nLogin Successfull\n\n");
			Receptionist_displayMenu(); 
		}
		else
		{
			printf("\nEnter valid Username/Password\n");
		}
		
		printf("\nDo you Want to Login Again ? (1/0) : ");
		scanf("%d",&ch);
	}while(ch == 1);
}
