#include<stdio.h>
#include<time.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>

//various macros storing the file paths used in the module
#define APPOINTMENT_DETAILS "text_files/appointment_details.txt"
#define RECEPTIONIST_DETAILS "text_files/receptionist_details.txt"
#define PATIENT_DETAILS "text_files/patient_details.txt"
#define DEPARTMENT_DETAILS "text_files/dept_details.txt"

//structure to store date
typedef struct Date{
	int day,mon,year,hrs,min,sec;
}date;

//structure to store name
typedef struct Name{
	char fname[15];
	char lname[15];
}name;

//structure to store address
typedef struct Address{
	char state[15];
	char city[15];
	int pincode;
}address;

/* Node Structure for Patient Entity */
typedef struct Patient{
	int patient_id;
	name pat_name;
	char passwd[20];
	long phone_no,aadhar;
	char mail_id[30];
	char gender;
	date dob;
	address addr;
	struct Patient* next;
}patient;

/* Node Structure for Department Entity */
typedef struct Department{
	int department_id;
	int doctor_id;
	char dept[20];
	name doc_name;
	char availability[1];
	struct Department* next;
}department;

/* Node Structure for Appointment Details */
typedef struct appointmentDetails{
    int appointmentID;
    int patientID;
    int doctorID;
    name pat_name;
    name doc_name;
    char dept[20];
    date dt;
    struct appointmentDetails* next;
}appointment;

/* Function Declarations */

/* Function to invoke Patient Module */
void GetPatient();
 
 /* Function for regular patient */ 
void regularPatient(); 

/* Function to accept patient details for registration */
void newPatient(); 

/* Function to display appointment Menu */
void appointmentMenu(int); 

/* Function to Cancel appointment */
void CancelAppointment(int); 

/* Function to display appointment */
void DisplayAppointment(int); 

/* Function to book appointment */
void BookAppointment(int); 

 /* Function to update doctor availability */
void updateDoctorAvailability(int);

/* Function to check Availability of doctor */
int checkDoctorAvailability(char*); 

/* Function to read appointment details and store in linked list */
appointment* acceptAppointment(appointment*); 

/* Function to read department details and store in linked list */
department* acceptDepartment(department*); 

/* Function to check for valid appointment */
int isValidAppointment(int,int); 

/* Function to check for valid patient id and password */
int isValidCredentials(int,char*); 

/* Function to validate Date */
int validate_date(int,int,int); 

/* Function to validate Mail ID */
int validate_mail(char*); 

/* Function to validate Aadhar Number */
int validate_aadhar(long); 

/* Function to validate Phone Number */
int validate_phone(long); 

/* Function to validate pincode */
int validate_pincode(long);

/* Function to remove node from linked list */
appointment* removeNode(appointment*,int); 



