#include "patient.h"

/* Function to delete a Node from Linked List  */
appointment* removeNode(appointment* head, int app_id)
{
	if(head == NULL) 
		return head;
	appointment *temp,*prev;
	if(head->appointmentID == app_id)
	{
		temp = head;
		head = head->next;
		free(temp);
	}
	else
	{
		temp = head;
		while(temp != NULL && temp->appointmentID != app_id)
		{
			prev = temp;
			temp = temp->next;
		}
		prev->next = temp->next;
		free(temp);
	}
	return head;
}

/* Function to validate phone number */
int validate_phone(long ph_no)
{
	int cnt = 10;
	while(ph_no > 0)
	{
		ph_no/=10; cnt--;
	}
	return (cnt == 0);
}

/* Function to validate aadhar number */
int validate_aadhar(long aadhar)
{
	int cnt = 12;
	while(aadhar > 0)
	{
		aadhar/=10; cnt--;
	}
	return (cnt == 0);
}

/* Function to validate Mail ID */
int validate_mail(char *mail)
{
	if((mail[0] >= 'a' && mail[0] <= 'z') || (mail[0] >= 'A' || mail[0] <= 'Z'))
	{
		// check for @ sign
		int pos = -1;
		for(int i=0; i<strlen(mail); ++i)
		{
			if(mail[i] == '@') pos = i;
		}
		if(pos == -1) 
			return 0;
		else
		{
			int pos2 = -1;
			for(int i=pos; i<strlen(mail); ++i)
			{
				// check for . after @ sign
				if(mail[i] == '.') pos2 = i;
			}
			if(pos2 == -1 || pos2 == strlen(mail)-1) 
				return 0;
			else 
				return 1;
		}
	}
	else return 0;
}

/* Function to validate Date */
int validate_date(int day, int mon, int year)
{
	if(mon < 1 || mon > 12) 
		return 0;
	if(year < 1000 || year > 9999)
	 	return 0;
	
	if(mon == 2){
		if(day < 0 || day > 29) 
			return 0;
		if(day == 29){
			if(year % 4 != 0) 
				return 0;
			if(year % 100 == 0 && year % 400 != 0) 
				return 0;
		}
	}
	else if(mon == 1 || mon == 3 || mon == 5 || mon == 7 || mon == 8 || mon == 10 || mon == 12){
		if(day < 1 || day > 31) 
			return 0;
	}
	else{
		if(day < 1 || day > 30) 
			return 0;
	}
	
	return 1;
}

/* Function to validate Time */
int validate_time(int hrs, int min, int sec)
{
	return ((hrs >= 0 && hrs <= 23) && (min >= 0 && min <= 59) && (sec >= 0 && sec <= 59));
}

/* Function to validate pincode */
int validate_pincode(long pincode)
{
	int cnt = 6;
	while(pincode > 0)
	{
		pincode/=10; cnt--;
	}
	return (cnt == 0);
}

/* Function to check for valid patient username and password */
int isValidCredentials(int pat_id, char *password)
{
	int flg = 0;
	char str[120];
	
	FILE *fptr;
	fptr = fopen(PATIENT_DETAILS,"r"); /* Opening file in read mode */
	
	if(fptr == NULL)
	{
		printf("\nError! Cannot Open File...\n");
		exit(1);
	}
	
	while(fgets(str,sizeof(str),fptr) != NULL)
	{
		char* token = strtok(str,",");
		int p_id = atoi(token); // convert string to int;
		if(p_id == pat_id)
		{ 
			token = strtok(NULL,",");
			if(strcmp(token,password) == 0)
			{
				flg = 1;
				break;
			}
		}
	}
	
	fclose(fptr);
	return flg;
}

/* Function to check if Appointment ID is valid or not */
int isValidAppointment(int pat_id, int app_id)
{
	int a_id,p_id,flg = 0;
	char str[100];
	
	FILE *fptr;
	fptr = fopen(APPOINTMENT_DETAILS,"r");
	
	if(fptr == NULL)
	{
		printf("\nError! Cannot Open File...\n");
		exit(1);
	}
	
	while(fgets(str,sizeof(str),fptr) != NULL)
	{
		char *token = strtok(str,",");
		a_id = atoi(token); // converting string to int
		if(a_id == app_id)
		{
			token = strtok(NULL,",");
			p_id = atoi(token); // converting string to int
			if(p_id == pat_id)
			{
				flg = 1;
				break;
			}
		}
	}
	
	fclose(fptr);
	return flg;
}

/* Function to read department details from file and store in linked list */
department* acceptDepartment(department *head)
{
	
	int dept_id,doc_id;
	char str[100];
	char arr[6][20];
	
	FILE *fptr;
	fptr = fopen(DEPARTMENT_DETAILS,"r");
	
	if(fptr == NULL)
	{
		printf("\nError ! Cannot Open File\n");
		exit(1);
	}
	
	while(fgets(str,sizeof(str),fptr) != NULL)
	{
		int p = 0;
		char *token = strtok(str,",");
		while(token != NULL)
		{
			strcpy(arr[p],token);
			token = strtok(NULL,",");
			p++;
		}
		
		department *newnode = malloc(sizeof(department));
		newnode->next = NULL;
		
		dept_id = atoi(arr[0]);
		doc_id = atoi(arr[2]);
		newnode->department_id = dept_id;
		newnode->doctor_id = doc_id;
		strcpy(newnode->dept,arr[1]);
		strcpy(newnode->doc_name.fname,arr[3]);
		strcpy(newnode->doc_name.lname,arr[4]);
		strcpy(newnode->availability,arr[5]);
		
		if(head == NULL)
		{
			head = newnode;
		}
		else
		{
			department *temp = head;
			while(temp->next != NULL)
			{
				temp = temp->next;
			}
			temp->next = newnode;
		}
	}
	fclose(fptr);
	return head;
}

/* Function to read appointment details from file and store in linked list */
appointment* acceptAppointment(appointment *head)
{
	int a_id,p_id,d_id;
	date dt={0};
	char str[100];
	char st[10][15];
	
	FILE *fptr;
	fptr = fopen(APPOINTMENT_DETAILS,"r");
	
	if(fptr == NULL)
	{
		printf("\nError! Cannot Open File...\n");
		exit(1);
	}
	
	while(fgets(str,sizeof(str),fptr) != NULL)
	{
		char *token = strtok(str,",");
		int p=0;
		while(token != NULL)
		{
			strcpy(st[p],token);
			token = strtok(NULL,",");
			p++;
		}
		a_id = atoi(st[0]); 
		p_id = atoi(st[1]);
		d_id = atoi(st[2]);
		
		
		appointment *newnode = (appointment*)malloc(sizeof(appointment));
		
		newnode->next = NULL;
		newnode->appointmentID = a_id;
		newnode->patientID = p_id;
		newnode->doctorID = d_id;
		strcpy(newnode->pat_name.fname,st[3]);
		strcpy(newnode->pat_name.lname,st[4]);
		strcpy(newnode->doc_name.fname,st[5]);
		strcpy(newnode->doc_name.lname,st[6]);
		strcpy(newnode->dept,st[7]);
		
		int id = 0;
		token = strtok(st[8],"/");
		
		while(token != NULL)
		{
			int val = atoi(token); // converting string to int
			
			if(id == 0) 
				dt.day = val;
			else if(id == 1) 
				dt.mon = val;
			else 
				dt.year = val;
		
			token = strtok(NULL,"/");
			id++;
		}
		
		newnode->dt.day = dt.day;
		newnode->dt.mon = dt.mon;
		newnode->dt.year = dt.year;
		
		id = 0;
		token = strtok(st[9],":");
		
		while(token != NULL)
		{
			int val = atoi(token); // converting string to int
			
			if(id == 0) 
				dt.hrs = val;
			else if(id == 1) 
				dt.min = val;
			else 
				dt.sec = val;
			
			token = strtok(NULL,":");
			id++;
		}
		
		newnode->dt.hrs = dt.hrs;
		newnode->dt.min = dt.min;
		newnode->dt.sec = dt.sec;
		
		if(head == NULL)
		{
			head = newnode;
		}
		else
		{
			appointment* temp = head;
			while(temp->next != NULL)
			{
				temp = temp->next;
			}
			temp->next = newnode;
		}
	}
	fclose(fptr);
	return head;
}

/* Function to check doctor availability. Returns true if doctor is available otherwise false. Department name is passed as argument */ 
int checkDoctorAvailability(char *str)
{ 
	int flg = 0;
	department *head = NULL;
	head = acceptDepartment(head); // reading department details and storing in linked list
	
	department *temp = head;
	while(temp != NULL)
	{ // looking for department name by traversing the linked list
		if(strcmp(temp->dept,str) == 0)
		{
			//department found, now check for availability of doctor
			if(temp->availability[0] == 'y')
			{
				flg = 1;
				break;
			}
		}
		temp = temp->next;
	}
	while(head != NULL)
	{
		temp = head;
		head = head->next;
		free(temp);
	}
	return flg;
}

/* Function to update doctor availability */
void updateDoctorAvailability(int doc_id)
{
	department *head = NULL, *temp;
	head = acceptDepartment(head);
	temp = head;
	
	while(temp != NULL)
	{
		if(temp->doctor_id == doc_id)
		{
			if(temp->availability[0] == 'y')
			{ 
				temp->availability[0] = 'n';
			}
			else
			{
				temp->availability[0] = 'y';
			}
			break;
		}
		temp = temp->next;
	}
	
	temp = head;
	
	FILE *fptr;
	fptr = fopen(DEPARTMENT_DETAILS,"w");
	
	if(fptr == NULL)
	{
		printf("\nError ! Cannot Open File\n");
		exit(1);
	}
	
	while(temp != NULL)
	{
		fprintf(fptr,"%d,%s,%d,%s,%s,%s",temp->department_id,temp->dept,temp->doctor_id,temp->doc_name.fname,temp->doc_name.lname,temp->availability);
		temp = temp->next;
	}
	
	while(head != NULL)
	{
		temp = head;
		head = head->next;
		free(temp);
	}
	
	fclose(fptr);
}

/* Function to book an Appointment. Patient ID is passed as an argument. Reload the department file and appointment file to see changes*/
void BookAppointment(int pat_id)
{
	
	int app_id,doc_id,choice,aval,counter=-1;
	char dept[20],buff[100];
	date dt={0}; name pat_name,doc_name;
	char dept_list[4][20] = {"Cardiology","Dermology","Neurology","Orthopedic"};
	
	while(1)
	{
		system("clear");
		printf("\n------------*** Select Department ***------------\n\n");
		printf("\t\t1. Cardiology\n\t\t2. Dermology\n\t\t3. Neurology\n\t\t4. Orthopedic\n\t\t0. Go Back\n\n");

		printf("Enter your choice :: ");
		scanf("%d",&choice);
		
		if(choice < 0 || choice > 4) continue;
		break;
	}
	
	if(choice != 0)
	{
		aval = checkDoctorAvailability(dept_list[choice-1]);
		
		if(!aval)
		{
			printf("\n\n--------------------------------------------\n");
			printf("All Appointments Booked. Please try later !\n");
			printf("--------------------------------------------\n\n");
		}
		else{
			while(1)
			{
				printf("\n\nEnter Appointment Date (dd/mm/yyyy) :: ");
				scanf("%d/%d/%d",&dt.day,&dt.mon,&dt.year);
				if(!validate_date(dt.day,dt.mon,dt.year))
				{ // validation of Date
					printf("\nEnter valid Date. !!\n");
					sleep(1); // wait for 1 second
					for(int i=0; i<5; ++i)
					{
						printf("\33[2K"); // erase the entire line, cursor does not move to the beginning of line
						printf("\033[A"); // moves up one row, cursor does not move to the beginning of line
					}
					printf("\33[2K");
					printf("\r"); // cursor moves to the beginning of line
				}
				else break;
			}
			
			while(1)
			{
				printf("Enter Appointment time (hr:min:sec) :: ");
				scanf("%d:%d:%d",&dt.hrs,&dt.min,&dt.sec);
				if(!validate_time(dt.hrs,dt.min,dt.sec))
				{ // validation of Time
					printf("\nEnter valid Time. !!\n");
					sleep(1); // wait for 1 second
					for(int i=0; i<3; ++i)
					{
						printf("\33[2K"); // erase the entire line, cursor does not move to the beginning of line
						printf("\033[A"); // moves up one row, cursor does not move to the beginning of line
					}
					printf("\33[2K");
					printf("\r"); // cursor moves to the beginning of line
				}
				else break;
			}
			
			FILE *fptr;
			
			// Reading from appointment details file to get the latest appointment ID
			fptr = fopen(APPOINTMENT_DETAILS,"r");
			if(fptr == NULL)
			{
				printf("\nError ! Cannot Open File\n");
			}
			
			while(fgets(buff,sizeof(buff),fptr) != NULL)
			{
				char *token = strtok(buff,",");
				counter = atoi(token);
			}
			
			if(counter == -1) 
				app_id = 500; // if there are no records in appointment details file, set appointment ID to 500 otherwise use the last appointment ID 
			else 
				app_id = counter+1;
			
			
			
			printf("\nAppointment id : %d",app_id); 
			fclose(fptr);
			
			// Reading from patient details file to get patient first name and last name
			fptr = fopen(PATIENT_DETAILS,"r");
			
			if(fptr == NULL)
			{
				printf("\nError ! Cannot Open File\n");
			}
			
			while(fgets(buff,sizeof(buff),fptr) != NULL)
			{
				char *token = strtok(buff,",");
				int p_id = atoi(token);
				if(p_id == pat_id)
				{
					token = strtok(NULL,",");
					token = strtok(NULL,",");
					strcpy(pat_name.fname,token);
					token = strtok(NULL,",");
					strcpy(pat_name.lname,token);
					break;
				}
			}
			fclose(fptr);
			
			// Reading from department details file to get doc_id and dept_id associated with department;
			department *head = NULL;
			head = acceptDepartment(head);
			
			department *temp = head;
			while(temp != NULL)
			{
				if(strcmp(temp->dept,dept_list[choice-1]) == 0 && temp->availability[0] == 'y')
				{
					strcpy(doc_name.fname,temp->doc_name.fname);
					strcpy(doc_name.lname,temp->doc_name.lname);
					doc_id = temp->doctor_id;
					break;
				}
				temp = temp->next;
			}
			while(head != NULL)
			{
				temp = head;
				head = head->next;
				free(temp);
			}
			
			// Wrting data to appointment details file
			fptr = fopen(APPOINTMENT_DETAILS,"a");
			
			if(fptr == NULL)
			{
				printf("\nError ! Cannot Open File\n");
			}
			
			fprintf(fptr,"%d,%d,%d,%s,%s,%s,%s,%s,%d/%d/%d,%d:%d:%d\n",app_id,pat_id,doc_id,pat_name.fname,pat_name.lname,doc_name.fname,doc_name.lname,dept_list[choice-1],dt.day,dt.mon,dt.year,dt.hrs,dt.min,dt.sec);
			fclose(fptr);
			
			printf("\n\n------------------------------------------------\n");
			printf("Your Appointment has been booked successfully !");
			printf("\n------------------------------------------------\n\n");
			
			// After booking appointment change availability of doctor
			updateDoctorAvailability(doc_id);
		}
	}
}

/* Function to Display an Appointment. Patient ID is passed as an argument. */
void DisplayAppointment(int pat_id)
{
	int app_id,ch;
	
	do{
		ch = 0;
		printf("\nEnter Appointment ID : ");
		scanf("%d",&app_id);
		int valid = isValidAppointment(pat_id,app_id); // function to check if Appointment ID is valid or not
		
		if(valid)
		{
			int a_id;
			char str[100];
			char st[10][15];
			
			FILE *fptr;
			fptr = fopen(APPOINTMENT_DETAILS,"r");
			
			if(fptr == NULL)
			{
				printf("\nError! Cannot Open File...\n");
				exit(1);
			}
			
			while(fgets(str,100,fptr) != NULL)
			{
				char *token = strtok(str,",");
				int p=0;
				while(token != NULL)
				{
					strcpy(st[p],token);
					token = strtok(NULL,",");
					p++;
				}
				a_id = atoi(st[0]); // converting string to int
				if(a_id == app_id)
				{
					printf("\n-----------------*** Appointment Details ***-----------------\n\n");
					printf("Appointment ID   :: %s\n",st[0]);
					printf("Patient ID       :: %s\n",st[1]);
					printf("Doctor ID        :: %s\n",st[2]);
					printf("Patient Name     :: %s %s\n",st[3],st[4]);
					printf("Doctor Name      :: %s %s\n",st[5],st[6]);
					printf("Department       :: %s\n",st[7]);
					printf("Appointment Date :: %s\n",st[8]);
					printf("Appointment Time :: %s\n",st[9]);
					break;
				}
			}
			fclose(fptr);
		}
		else
		{
			printf("\n----------------------------------");
			printf("\nEnter valid Appointment ID !\n");
			printf("----------------------------------\n");
			
			printf("\nDo you wish to continue (1/0): ");
			scanf("%d",&ch);
		}
	}
	while(ch == 1);
}

/* Function to Cancel an Appointment. Patient ID is passed as an argument. Reload the department file and appointment file to see changes */
void CancelAppointment(int pat_id)
{
	int app_id,doc_id,ch;
	char buff[120];
	appointment* head = NULL;
	head = acceptAppointment(head); // function to read appointment details from file and store in Linked List
	if(head == NULL)
	{
		printf("\nNo Appointments to Cancel !\n");
		return;
	}
	
	do{
		ch = 0;
		printf("\nEnter Appointment ID : ");
		scanf("%d",&app_id);
		int valid = isValidAppointment(pat_id,app_id); // function to check if Appointment ID is valid or not
		if(valid)
		{
			// Get Doctor ID to update doctor availability to "n" after appointment is cancelled
			FILE *fptr;
			fptr = fopen(APPOINTMENT_DETAILS,"r");
			
			if(fptr == NULL)
			{
				printf("\nError ! Cannot Open File\n");
				exit(1);
			}
			
			while(fgets(buff,sizeof(buff),fptr) != NULL)
			{
				char *token = strtok(buff,",");
				int a_id = atoi(token);
				if(a_id == app_id)
				{
					token = strtok(NULL,",");
					token = strtok(NULL,",");
					doc_id = atoi(token);
					break;
				}
			}
			fclose(fptr);
			
			head = removeNode(head,app_id); // function to delete record associated with app_id
			// if head is Null then print: There are no appointments to cancel !
			fptr = fopen(APPOINTMENT_DETAILS,"w");
			
			if(fptr == NULL)
			{
				printf("\nError! Cannot Open File...\n");
				exit(1);
			}
			
			appointment* temp = head;
			while(temp != NULL)
			{
			//app_id, pat_id, doc_id, pat_fname, pat_lname, doc_fname, doc_lname, department, app_date, app_time
				fprintf(fptr,"%d,%d,%d,%s,%s,%s,%s,%s,%d/%d/%d,%d:%d:%d",temp->appointmentID,temp->patientID,temp->doctorID,temp->pat_name.fname,temp->pat_name.lname,temp->doc_name.fname,temp->doc_name.lname,temp->dept,temp->dt.day,temp->dt.mon,temp->dt.year,temp->dt.hrs,temp->dt.min,temp->dt.sec);
				if(temp->next != NULL) fprintf(fptr,"\n");
				temp = temp->next;	
			}
			fclose(fptr);
			
			printf("\nAppointment #%d Cancelled !\n",app_id);

			updateDoctorAvailability(doc_id);
			
			while(head != NULL)
			{
				temp = head;
				head = head->next;
				free(temp);
			}
		}
		else
		{
			printf("\n----------------------------------");
			printf("\nEnter valid Appointment ID !\n");
			printf("----------------------------------\n");
			
			printf("\nDo you wish to continue (1/0): ");
			scanf("%d",&ch);
		}
	}
	while(ch == 1);
}

/* Function to display Appointment Menu. Patient ID is passed as an argument */
void appointmentMenu(int pat_id)
{
	int ch;
	do{
		while(1)
		{
			system("clear");
			printf("\n\n-----------------*** Appointment Menu ***-----------------\n");
			printf("\n\t\t1. Book Appointment \n\t\t2. Display Appointment\n\t\t3. Cancel Appointment\n\t\t4. Logout\n\t\t0. Exit\n");
			printf("\nEnter your choice :: ");
			scanf("%d",&ch);
			if(ch < 0 || ch > 4)
			{
				continue;
			}
			break;
		}
		
		switch(ch)
		{
			case 1:
				BookAppointment(pat_id);
				break;
			case 2:
				DisplayAppointment(pat_id);
				break;
			case 3:
				CancelAppointment(pat_id);
				break;
			case 4:
				ch = 0;
				break;
			case 0:
				exit(0);
		}
		
		if(ch != 0)
		{
			printf("\nGo Back to Appointment Menu (1/0) : ");
			scanf("%d",&ch);
		}
		if(ch == 0)
		{
			printf("\nYou've been Logged Out !\n");
		}
	}
	while(ch != 0);
}

/* Function to register for new patient */
void newPatient()
{
	name pat_name;
	long ph_no,aadhar;
	char pass[20],mail[30],new_pass[20];
	char gender;
	date dt={0}; address addr;
	
	printf("\n-------------*** Registration Page ***-------------\n");
	
	printf("\nEnter Patient First Name         :: ");
	scanf("%s",pat_name.fname);
	
	printf("Enter Patient Last Name          :: ");
	scanf("%s",pat_name.lname);
	
	while(1)
	{
		printf("Enter Phone No.                  :: ");
		scanf("%ld",&ph_no);
		if(!validate_phone(ph_no))
		{ // validation of phone no (It must be 10 digit)
				printf("\nEnter valid phone no. !!\n");
				sleep(1); // wait for 1 second
				for(int i=0; i<3; ++i)
				{
					printf("\33[2K"); // erase the entire line, cursor does not move to the beginning of line
					printf("\033[A"); // moves up one row, cursor does not move to the beginning of line
				}
				printf("\33[2K");
				printf("\r"); // cursor moves to the beginning of line
		}
		else break;
	}
	
	while(1)
	{
		printf("Enter Aadhar No.                 :: ");
		scanf("%ld",&aadhar);
		if(!validate_aadhar(aadhar))
		{ // validation of aadhar no (It must be 12 digit)
				printf("\nEnter valid aadhar no. !!\n");
				sleep(1); // wait for 1 second
				for(int i=0; i<3; ++i)
				{
					printf("\33[2K"); // erase the entire line, cursor does not move to the beginning of line
					printf("\033[A"); // moves up one row, cursor does not move to the beginning of line
				}
				printf("\33[2K");
				printf("\r"); // cursor moves to the beginning of line
		}
		else break;
	}
	
	while(1)
	{
		printf("Enter Mail ID.                   :: ");
		scanf("%s",mail);
		if(!validate_mail(mail))	// validation of Mail ID (It must include @ symbol)
		{ 
				printf("\nEnter valid Mail ID. !!\n");
				sleep(1); // wait for 1 second
				for(int i=0; i<3; ++i)
				{
					printf("\33[2K"); // erase the entire line, cursor does not move to the beginning of line
					printf("\033[A"); // moves up one row, cursor does not move to the beginning of line
				}
				printf("\33[2K");
				printf("\r"); // cursor moves to the beginning of line
		}
		else break;
	}
	while(1)
	{
		while(getchar() != '\n');
		printf("Enter Gender (M/F/O)             :: ");
		scanf("%c",&gender);
		if(!(gender == 'M' || gender == 'F' || gender == 'O'))
		{ // validation of gender (M/F/O)
			printf("\033[A\r"); // move up one row and move cursor to beginning of line
			printf("\33[2K"); // erase the entire line
		}
		else break;
	}
	
	while(1)
	{
		printf("Enter Date of Birth (dd/mm/yyyy) :: ");
		scanf("%d/%d/%d",&dt.day,&dt.mon,&dt.year);
		if(!validate_date(dt.day,dt.mon,dt.year))
		{ // validation of Date
				printf("\nEnter valid Date. !!\n");
				sleep(1); // wait for 1 second
				for(int i=0; i<3; ++i)
				{
					printf("\33[2K"); // erase the entire line, cursor does not move to the beginning of line
					printf("\033[A"); // moves up one row, cursor does not move to the beginning of line
				}
				printf("\33[2K");
				printf("\r"); // cursor moves to the beginning of line
		}
		else break;
	}
	
	printf("Enter State                      :: ");
	scanf("%s",addr.state);
	printf("Enter City                       :: ");
	scanf("%s",addr.city);
	while(1)
	{
		printf("Enter Pincode                    :: ");
		scanf("%d",&addr.pincode);
		if(!validate_pincode(addr.pincode))
		{ // validation of pincode (It must be 6 digit)
				printf("\nEnter valid pincode. !!\n");
				sleep(1); // wait for 1 second
				for(int i=0; i<3; ++i)
				{
					printf("\33[2K"); // erase the entire line, cursor does not move to the beginning of line
					printf("\033[A"); // moves up one row, cursor does not move to the beginning of line
				}
				printf("\33[2K");
				printf("\r"); // cursor moves to the beginning of line
		}
		else break;
	}
	
	
	printf("\n\n-------------------------------------------\n");
	printf("Registration completed successfully !\n");
	printf("-------------------------------------------\n\n");
	
	while(1)
	{
		printf("Enter new Password :: ");
		scanf("%s",pass);
		printf("Confirm Password   :: ");
		scanf("%s",new_pass);
		if(strcmp(pass,new_pass) == 0)
		{
			printf("\n\n-------------------------------------------\n");
			printf("Password created successfully !\n");
			printf("-------------------------------------------\n\n");
			break;
		}
		else
		{
			printf("\n\n-------------------------------------------\n");
			printf("Password does not match !\n");
			printf("-------------------------------------------\n\n");
		}
	}
	FILE *fptr;
	int counter = -1;
	// getting current counter by reading from file
	fptr = fopen(PATIENT_DETAILS,"r");
	char buff[120];
	
	while(fgets(buff,sizeof(buff),fptr) != NULL)
	{
		char *token = strtok(buff,",");
		counter = atoi(token);
	}
	
	if(counter == -1) 
		counter = 100;
	else 
		counter++;
	
	fclose(fptr);
	
	printf("\nPatient id: %d",counter);
	
	// writing patient details into file
	fptr = fopen(PATIENT_DETAILS,"a");
	
	fprintf(fptr,"%d,%s,%s,%s,%ld,%ld,%s,%c,%d/%d/%d,%s,%s,%d\n",counter,pass,pat_name.fname,pat_name.lname,ph_no,aadhar,mail,gender,dt.day,dt.mon,dt.year,addr.state,addr.city,addr.pincode);
	
	fclose(fptr);
}

//function to login as regular patient
void regularPatient()
{
	int p_id,ch; 
	char pass[20];
	
	do{
		system("clear");
		printf("\n---------------- *** Welcome Patient *** ----------------\n");
		printf("\nEnter Patient ID : ");
		scanf("%d",&p_id);
		printf("Enter Password   : ");
		scanf("%s",pass);
		
		int valid = isValidCredentials(p_id,pass); // function to validate patient username and password
		
		if(valid)
		{
			printf("\nLogin Successfull\n\n");
			appointmentMenu(p_id); // function to display appointment Menu 
			ch = 0;
		}
		else
		{
			printf("\nEnter valid Patient ID/Password\n");
			
			printf("\nDo you Want to Login Again ? (1/0) : ");
			scanf("%d",&ch);
		}
	}
	while(ch == 1);
}

/* Function to invoke get patient Module */
void GetPatient()
{

	int ch;
	do{
		system("clear");
		while(1)
		{
			printf("\n\n-----------------*** Patient Menu ***-----------------\n");
			printf("\n\t\t1. New Patient\n\t\t2. Regular Patient\n\t\t0. Go Back\n");
			printf("\nEnter your choice :: ");
			scanf("%d",&ch);
			if(ch < 0 || ch > 2)
			{
				system("clear");
				continue;
			}
			break;
		}
		
		switch(ch)
		{
			case 1:
				newPatient();
				break;
			case 2:
				regularPatient();
				break;
			case 0:
				break;
				
		}
		if(ch != 0)
		{
			printf("\nGo Back to Patient Menu (1/0) : ");
			scanf("%d",&ch);
		}
	}
	while(ch != 0);
}
