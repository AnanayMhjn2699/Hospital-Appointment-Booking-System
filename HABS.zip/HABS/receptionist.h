#include "patient.h"

//various macros used
#define R_BOOK 1
#define R_CANCEL 2
#define R_DISPLAY 3
#define R_LOGOUT 4
#define R_EXIT 0


//structure to store shift time
typedef struct shiftTime{
	date start;
	date finish;
}shift;

/* Node Structure for Receptionist */
typedef struct receptionist{
	int receptionist_id;
	char passwd[20]; 
	name rec_name;
	long phone_no; 
	shift receptionist_shiftTime;
	struct Receptionist* next;
}rec;

/* Function declarations */

/* function to invoke Receptionist Module */
void GetReceptionist(); 

/* Function to display Receptionist Menu */
void Receptionist_displayMenu(); 

/* function to display an Appointment */
void Receptionist_Display_Appointment(); 

/* function to Cancel an Appointment */
void Receptionist_Cancel_Appointment(); 

/* Function to display Patient Menu */
void Receptionist_GetPatient(); 

/* Function for regular patient */
void Receptionist_regularPatient(); 

/* function to check if receptionist username and password entered is correct or not */
int Receptionist_isValid_Receptionist(int,char*); 

/* function to check if Appointment ID entered is correct or not */
int Receptionist_isValid_Appointment(int); 

/* Function to reposition the cursor */
void Reset_Cursor(); 

